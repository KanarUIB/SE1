import java.util.Scanner;

public class SpielUI {

	private static Scanner s = new Scanner(System.in);
	private static Spiel spiel;
	

	public static void main(String[] args) {

		String start = null;
		do {
			System.out.println("Geben Sie start ei um das Spiel zu beginnen");
			start = s.next();	

		}while(!start.equalsIgnoreCase("start"));
		
		spiel = new Spiel();

		System.out.println(spiel.getBrett().toString());
		
		String richtung = s.next();
		spiel.ziehen(richtung, spiel.sp.wuerfeln());

	}
}
