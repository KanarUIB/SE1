
public class Spielfeld {
	
	private String ID;
	private boolean sichereZone;
	private boolean heim;
	private Spielfigur spielfigur = null;
	
	
	
	Spielfeld(String ID, boolean sichereZone, boolean heim){
		setID(ID);
		setSichereZone(sichereZone);
		setHeim(heim);
	}

	
	
	public void figurL�schen(String ID) {
		
		spielfigur = null;
	}



	public String getID() {
		return ID;
	}

	
	public void setID(String iD) {
		ID = iD;
	}


	public boolean getSichereZone() {
		return sichereZone;
	}


	public void setSichereZone(boolean sichereZone) {
		this.sichereZone = sichereZone;
	}


	public boolean getHeim() {
		return heim;
	}


	public void setHeim(boolean heim) {
		this.heim = heim;
	}


	public Spielfigur getSpielfigur() {
		return spielfigur;
	}


	public void setSpielfigur(Spielfigur spielfigur) {
		this.spielfigur = spielfigur;
	}
	
	
	
}
