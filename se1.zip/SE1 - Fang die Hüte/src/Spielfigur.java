
public class Spielfigur {

	private Farbe farbe;
	private static final int anzahl = 4;
	
	
	
	Spielfigur(Farbe farbe){
		setFarbe(farbe);
	}
	
	
	
	public Farbe getFarbe() {
		return farbe;
	}
	private void setFarbe(Farbe farbe) {
		this.farbe = farbe;
	}
	
	
	
	
	
	
}
