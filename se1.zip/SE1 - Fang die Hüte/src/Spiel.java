import java.util.ArrayList;

public class Spiel {

	private Spielbrett brett;

	private ArrayList<Spieler> spieler = new ArrayList<Spieler>(4);

	public Spieler sp = new Spieler("Ken", Farbe.Rot);

	private Spieler spielerAmZug = null;
	private Spieler[] reihenfolge;


	Spiel(){
		brett = new Spielbrett();

	}

	public Spielbrett getBrett() {
		return brett;
	}

	public void ziehen(String richtung, int w�rfel) {

		System.out.println(brett.getSpielbrett()[1][1]);




	}

	public void getErlaubteZuege(int wuerfel) {
		
		char buchstabe;
		int nummer;
		
		
		
		ArrayList<String> zuege = new ArrayList<String>();
		String[] erlaubteFiguren = new String[4];
		
		String farbe = spielerAmZug.getFarbe().toString();
		
		for(int y = 0; y < brett.getSpielbrett().length; y++) {
	
			for(int x = 0; x < brett.getSpielbrett()[y].length; x++) {
				
				buchstabe = brett.getSpielbrett()[y][x].getID().charAt(0);
				
				nummer = brett.getSpielbrett()[y][x].getID().charAt(1);
				
				if(brett.getSpielbrett()[y][x] != null && brett.getSpielbrett()[y][x].getSpielfigur() != null && brett.getSpielbrett()[y][x].getSpielfigur().getFarbe().toString().equals(farbe)) {
					
					zuege.add(brett.getSpielbrett()[y][x].getID());
					
					
				}
				
			}
		}







	}


	public ArrayList<Spieler> getSpieler(){
		return spieler;
	}


	public Spieler getSpielerAmZug() {
		return spielerAmZug;
	}

	private void setReihenfolge() {

		int[] wuerfe = new int[spieler.size()];

		for(int x = 0; x < spieler.size(); x++) {
			wuerfe[x] = spieler.get(x).wuerfeln();

			System.out.println(wuerfe[x]);

			if(x > 0) {
				int z = x-1;
				while(z > 0) {
					if(wuerfe[x] > wuerfe[z]) {
						int temp = wuerfe[z];
						wuerfe[z] = wuerfe[x];
						wuerfe[x] = temp;
					}
				}
			}			
		}





	}

	public void addSpieler(String name, String farbe) {

		farbe.toLowerCase();

		switch(farbe) {

		case "rot":
			spieler.add(new Spieler(name,Farbe.Rot));
			break;

		case "blau":
			spieler.add(new Spieler(name,Farbe.Blau));
			break;

		case "gr�n":
			spieler.add(new Spieler(name,Farbe.Gruen));
			break;

		case "gelb":
			spieler.add(new Spieler(name,Farbe.Gelb));
			break;

		default:
			System.out.println("Falsche Eingaben");
			break;
		}
	}




}



