import java.util.ArrayList;

public class Spieler {

	private String name;
	private Farbe farbe;
	
	private int figurenGesamt = 4;
	
	private ArrayList<Spielfigur> figuren = new ArrayList<Spielfigur>();
	
	
	Spieler(String name, Farbe farbe){
		setName(name);
		setFarbe(farbe);
		setFiguren();
	}
	
	public ArrayList<Spielfigur> getFiguren(){
		return figuren;
	}
	
	
	private void setFiguren() {
		
		for(int x = 0; x < 4; x++) {
			figuren.add(new Spielfigur(getFarbe()));
		}
	}
	
	public void figurLoeschen() {
		figuren.remove(figuren.size()-1);
		figurenGesamt--;
	}
	
	private void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public Farbe getFarbe() {
		return farbe;
	}

	private void setFarbe(Farbe farbe) {
		this.farbe = farbe;
	}
	
	public int wuerfeln() {
		return (int) ((Math.random() * 5) + 1);
	}
	
	public void anzahlFiguren(char operator) {
		if(operator == '+') {
			figurenGesamt++;
		}else if(operator == '-') {
			figurenGesamt--;
		}
		
	}

	
}
