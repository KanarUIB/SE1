
public class test {

	public static void main(String[] args) {

		char s = 'A';
		s += 1;
		int nummer = 1;
		String ID = "" + s + (nummer+1);
		System.out.println(ID);

	}

}
