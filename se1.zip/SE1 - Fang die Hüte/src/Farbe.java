
public enum Farbe {
	Rot, Blau, Gelb, Gruen
}
