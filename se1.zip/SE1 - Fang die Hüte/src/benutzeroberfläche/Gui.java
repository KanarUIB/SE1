package benutzeroberfl�che;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Gui extends JFrame  implements ActionListener{



	private static final long serialVersionUID = 1L;




	JButton b = new JButton("Start");


	public static void main(String[] args) {

		Gui g = new Gui();


		JFrame jf = new JFrame();
		jf.setTitle("H�te fangen");
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout());

		jp.add(g.b);

		jf.setContentPane(jp);

		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
		jf.setSize(1000,1000);





	}




	@Override
	public void actionPerformed(ActionEvent act) {


		if(act.getSource() == b) {

		}

	}

}
