import java.util.LinkedList;

public class Spielbrett {


	//	private LinkedList<Spielfeld> spielbrett = new LinkedList<Spielfeld>();
	private Spielfeld[][] brett = new Spielfeld[15][15];

	//	public LinkedList<Spielfeld> getSpielbrett() {
	//		return spielbrett;
	//	}



	Spielbrett() {

		spielbrettErstellen();
	}

	public Spielfeld[][] getSpielbrett() {
		return brett;
	}

	
	public void figurL�schen(int x, int y) {
		char buchstabe = 65;
		buchstabe += x;
		int nummer = 1 + y;

		String ID = "" + buchstabe + nummer;

		getSpielbrett()[x][y].figurL�schen(ID);
	}


	public void spielbrettErstellen() {
		int x = 0;
		int y = 0;
		char buchstabe;
		int nummer;
		boolean sichereZone = false;
		boolean heim = false;

		for(y = 0; y < brett.length;y++) {
			nummer = 15;
			nummer -= y;
				
			for(x = 0; x < brett[y].length;x++) {
				buchstabe = 'A';
				buchstabe += x;
				String ID = "" + buchstabe +""+ nummer;
				if(((y == 0 || y == 14) && (x == 3 || x == 11)) || ((y == 3 || y == 11) && (x == 0 || x == 14)) || ((y == 4 || y == 10) && (x == 7)) || ((y == 7) && (x == 4 || x == 10))) {
					sichereZone = true;
				}
				if(((y == 0 || y == 14) && (x == 7)) || ((y == 7) && (x == 0 || x == 14))) {
					heim = true;
				}
				brett[y][x] = new Spielfeld(ID, sichereZone, heim);

				if((y != 0) && (y != 7) && (y != 14)) {
					x += 6;
				}
				sichereZone = false;
				heim = false;
			}
		}
	}


	@Override
	public String toString() {

		String ui = "";


		ui += "\t----------------------------------\n";
		for(int y = 0; y < brett.length; y++ ) {
			ui += "\t| ";
			for(int x = 0; x < brett[y].length; x++) {

				// Sichere Zonen
				if(brett[y][x] != null && brett[y][x].getSichereZone() == true) {
					ui += "!";

				}else if(brett[y][x] != null && brett[y][x].getHeim() == true) {			// Heim Zonen
					ui += "H";

				}else if(brett[y][x] != null && brett[y][x].getSichereZone() != true && brett[y][x].getHeim() != true){		//normale Zonen
					ui += "-";

				}else if(brett[y][x] == null){
					ui += " ";
				}

				//if(y != 0 || y != 7 || y != 14)
				ui += " ";
			}
			ui += " |\n";
		}
		ui += "\t----------------------------------";

		return ui;
	}

}
